require('maps')

vim.g.dir = '/tmp'
vim.g.backupdir = '/tmp'
vim.g.undodir = '/tmp'
vim.g.viewdir = '/tmp'

vim.cmd([[ autocmd BufWritePost * call rpcnotify(0, "saved", expand('%:p')) ]])
vim.cmd([[autocmd FileType * nnoremap <silent> <buffer> t call rpcnotify(0, "concatclip",  expand('%:p')]])

vim.cmd([[colorscheme zellner]])
vim.cmd([[set number]])
vim.cmd([[syntax off ]])
vim.cmd([[highlight clear LineNr ]])




vim.cmd([[ autocmd TextYankPost * let yanked_text = getreg('"') | call rpcnotify(0, "yanked", expand('<afile>'), line('.'), col('.'), expand('<sfile>'), line("'<"), col("'<"), yanked_text) ]])

vim.cmd([[ 
let g:execute_buffer_length_check = 1
augroup MyAutocmds
  autocmd!
  autocmd TextChanged,TextChangedI <buffer> call CheckBufferLength()
augroup END

let g:previous_buffer_length = line('$')

function! CheckBufferLength() abort
  if g:execute_buffer_length_check == 0
    return
  endif

  let current_buffer_length = line('$')
  if current_buffer_length > g:previous_buffer_length
    let line_number = line('.')
    call rpcnotify(0, 'addedline', line_number, current_buffer_length - g:previous_buffer_length, expand("%:p"))
  endif

  if current_buffer_length < g:previous_buffer_length
    let line_number = line('.')
    call rpcnotify(0, 'rmedline', line_number, g:previous_buffer_length - current_buffer_length,expand("%:p"))
  endif
  let g:previous_buffer_length = current_buffer_length
endfunction

 ]])

