local actions = require "telescope.actions"
local action_state = require "telescope.actions.state"
local pickers = require "telescope.pickers"
local finders = require "telescope.finders"
local sorters = require "telescope.sorters"
local previewers = require "telescope.previewers"

local previewer = previewers.new_buffer_previewer {
    get_buffer_by_name = function(entry)
        return entry.ordinal, entry.value
    end,
    define_preview = function(self, entry, status)
        vim.api.nvim_buf_set_lines(self.state.bufnr, 0, -1, false, entry.value)
        vim.api.nvim_buf_set_option(self.state.bufnr, 'filetype', 'plaintext')
    end,
}

function enter(prompt_buffer)
    local selected = action_state.get_selected_entry()
    local cmd = "call rpcnotify(0, 'intobuffer', '" .. selected[1] .. "')"
    vim.cmd(cmd)
    local cmd1 = 'let @"="' .. selected[1] .. '"'
    vim.cmd(cmd1)
    actions.close(prompt_buffer)
end

local opts = {
    layout_strategy = "vertical",
finder = finders.new_table({
    { ordinal = 'first', value = "Avdhut" },
    { ordinal = 'sde', value = "Sarvesh" },
}),
    sorter = sorters.get_generic_fuzzy_sorter({}),
    attach_mappings = function(prompt_buffer, map)
        map("i", "<CR>", enter)
        map("n", "<CR>", enter)
        return true
    end,
    previewer = previewer,
}

local lel = pickers.new(opts)
lel:find()

